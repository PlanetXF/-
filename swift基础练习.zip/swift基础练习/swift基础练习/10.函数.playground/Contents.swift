import Cocoa

func sum(a: Int, b: Int) -> Int {
    
    return a + b
}

let sumResult = sum(a: 10, b: 20)
print(sumResult)


// 返回元组
func parseUserInfo(info: String) -> (name: String, age: Int)? {
    let infos = info.components(separatedBy: ",")
    guard infos.count >= 2, let age = Int(infos[1]) else {
        return nil
    }
    return (infos[0], age)
}

let p: (name: String, age: Int)? = parseUserInfo(info: "zhangsan,20")
if let p = p {
    print(p.name)
    print(p.age)
}


// 形参由两部分组成：形参标签 & 形参名，标签暴露给调用者，形参名暴露给函数内部

func sum1(_ a: Int, _ b: Int) -> Int {
    
    return a + b
}

let sumResult1 = sum1(10, 20)
print(sumResult1)

func sum2(num1 a: Int, num2 b: Int) -> Int {
    
    return a + b
}

let sumResult2 = sum2(num1: 10, num2: 20)
print(sumResult2)

// 默认参数

func sum3(a: Int, b: Int = 10) -> Int {
    
    return a + b
}

let sumResult3 = sum3(a: 10, b: 40)
print("默认参数\(sumResult3)")

// 可变参数

func add(num: Int...) -> Int {
    var temp = 0
    for n in num {
        temp += n
    }
    return temp
}

let result1 = add(num: 1,2)
print("result1=\(result1)")

let result2 = add(num: 1,2,10)
print("result2=\(result2)")


// 引用

var a = 10, b = 20

func swapTwoNums(a: inout Int, b: inout Int) {
    let temp = b
    b = a
    a = temp
}

swapTwoNums(a: &a, b: &b)
print("a=\(a), b=\(b)")


// 函数嵌套

//
