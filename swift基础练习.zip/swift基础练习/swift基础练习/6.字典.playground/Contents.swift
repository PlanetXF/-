import Cocoa

var p: [String: Any] = ["name" : "zhangsan", "age" : 18, "sex" : "男"];

var dict: [String : Any] = ["height" : "178"]

p.isEmpty // 判空
p.count // 获取长度

p["address"] = "北京" // 增加或者修改某个字段的值
print(p)

p.updateValue("西安", forKey: "address") // 更新某个键的值
print(p)

p.updateValue("篮球", forKey: "hobby")
print(p)

p.removeValue(forKey: "address") // 移除某个键值对
print(p)

p.removeValue(forKey: "abc") // 移除某个键值对, 没有这个键值不会报错
print(p)

// 遍历

for key in p.keys {
    print(key)
}

for value in p.values {
    print(value)
}

for (key, value) in p {
    print("\(key), \(value)")
}

for (index, item) in p.enumerated() {
    print("\(index), \(item.key)-\(item.value)")
}


// 合并

for (key, value) in dict {
    p[key] = value
}

print(p)
