import Cocoa

var greeting = "Hello, playground"

/**
 
 @objc 是 Swift 中的一个重要属性（attribute），它的主要作用是让 Swift 代码能够与 Objective-C 代码交互。以下是它的核心作用和用法：

 一、核心作用

 兼容性桥梁：
 使 Swift 代码可以被 Objective-C 调用
 让 Swift 类/方法/属性在 Objective-C 运行时可见
 运行时特性：
 启用 Objective-C 的动态派发（dynamic dispatch）
 允许使用 Objective-C 的运行时特性（如 KVO、反射等）
 
 二、典型使用场景

 1. 需要被 Objective-C 调用的代码

 swift
 @objc class MySwiftClass: NSObject {
     @objc var name: String = ""
     
     @objc func greet() {
         print("Hello, \(name)!")
     }
 }
 现在 Objective-C 可以这样调用：

 objc
 MySwiftClass *obj = [[MySwiftClass alloc] init];
 [obj setName:@"John"];
 [obj greet];
 2. 需要 Objective-C 运行时特性的情况

 swift
 @objc class Observable: NSObject {
     @objc dynamic var value: Int = 0 // 启用KVO
 }
 3. 协议需要被 Objective-C 实现时

 swift
 @objc protocol MyProtocol {
     @objc optional func optionalMethod() // 可选方法
     func requiredMethod()
 }
 三、关键特性说明

 自动推断规则：
 继承自 NSObject 的类会自动推断 @objc
 重写或实现 @objc 方法时会自动推断
 标记为 @IBAction 或 @IBOutlet 时会自动推断
 dynamic 组合使用：
 swift
 @objc dynamic var property: String
 dynamic 强制使用 Objective-C 动态派发
 常用于需要 KVO 或方法交换（method swizzling）的场景
 名称重命名：
 swift
 @objc(OCCompatibleName)
 class MySwiftClass {}

 @objc(greetWithName:)
 func greet(name: String) {}
 四、Swift 4+ 的变化

 减少隐式推断：
 Swift 4 开始，编译器不再自动为所有 NSObject 子类的方法添加 @objc
 需要显式声明需要暴露给 Objective-C 的成员
 @objcMembers：
 swift
 @objcMembers class MyClass: NSObject {
     var name: String // 整个类成员自动暴露
 }
 批量标记整个类的成员为 @objc
 五、注意事项

 类型限制：
 只有继承自 NSObject 的类才能使用 @objc
 支持的参数/返回值类型有限（需兼容 Objective-C）
 性能影响：
 @objc 方法调用比纯 Swift 方法稍慢（因为动态派发）
 dynamic 会进一步增加开销
 可选协议方法：
 只有 @objc 协议才能有可选方法（optional）
 六、现代 Swift 中的最佳实践

 按需使用：
 只在需要与 Objective-C 交互时使用
 纯 Swift 项目尽量减少使用
 优先使用 Swift 原生特性：
 用 Swift 协议替代 @objc 协议
 用闭包替代 delegate 模式
 迁移策略：
 swift
 #if canImport(ObjectiveC)
 @objc func legacyMethod() {}
 #endif
 @objc 是 Swift 与 Objective-C 混合编程的关键，但随着 Swift 生态的成熟，它的使用频率正在逐渐降低。
 
 */
