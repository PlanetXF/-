import Cocoa

// 尾随闭包
func getNewList(score: [Int], op: (Int) -> Bool) -> [Int] {
    var temps: [Int] = [Int]()
    for item in score {
        if op(item) {
            temps.append(item)
        }
    }
    return temps
}

// 把闭包单拎出来
let newList = getNewList(score: [1, 2, 3, 4, 5, 6]) { num in
    num % 2 == 0
}

/**
 逃逸闭包
 1. 闭包作为一个参数传递给函数
 2. 传入函数的闭包如果在函数执行结束后才会被调用，那么这个闭包就叫做逃逸闭包
 3. 声明一个接受闭包作为形参的函数时，可以在形参的类型之前加上@escaping来明确闭包是允许逃逸的
 4. 逃逸闭包会在函数结束后才执行
 */

/**
 自动闭包
 1. 一种自动创建的闭包，用于包装函数参数的表达式
 2. 不接受任何参数，被调用时会返回被包装在其中的表达式的值
 3. 在形参的类型前加上@autoclosure关键字标识这是一个自动闭包
 */

func printIfTrue(predicate: @autoclosure () -> Bool) {
    if predicate() {
        print("is true")
    } else {
        print("is false")
    }
}

printIfTrue(predicate: 2 > 1)




