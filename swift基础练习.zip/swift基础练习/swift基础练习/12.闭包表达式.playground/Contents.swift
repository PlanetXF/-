import Cocoa

func getNewList(score: [Int], op: (Int) -> Bool) -> [Int] {
    var temps: [Int] = [Int]()
    for item in score {
        if op(item) {
            temps.append(item)
        }
    }
    return temps
}

let list = getNewList(score: [65, 75, 85, 95]) { (num: Int) -> Bool in
    return num > 80
}

let list2 = getNewList(score: [65, 75, 85, 95] , op: { (num: Int) -> Bool in return num > 60 })
 
print("list = \(list)")

// 简写

let list3 = getNewList(score: [65, 75, 85, 95] , op: { (num: Int) -> Bool in return num > 60 })

// 省略返回值，因为可以通过return后面的返回进行类型推断
getNewList(score: [65, 75, 85, 95] , op: { (num: Int) in return num > 60 })
// 省略形参类型
getNewList(score: [65, 75, 85, 95] , op: { num in return num > 60 })
// 但行函数体时可省略return
getNewList(score: [65, 75, 85, 95] , op: { num in num > 60 })
// 参数名称缩写，省略参数声明和in，改为$0 $1 $2 $3
getNewList(score: [65, 75, 85, 95] , op: { $0 > 60 })

