import Cocoa

var array: [String] = ["A", "Baby", "Apple", "Google", "Aunt"]

// 排序，改变原数组

array.sort { str1, str2 in
    str1 > str2
}

// 循环

array.forEach { str in
    print(str)
}

// 筛选

let filterArr = array.filter { str in
    str.starts(with: "A")
}
print(filterArr)

// map转换

//let mapArr = array.map { str in
//    "Hello-" + str
//}

// 简化
let mapArr = array.map { "Hello-\($0)" }

print(mapArr)


// reduce合规
let arr = [12, 33, 23]
let sumArr = arr.reduce(0) { partialResult, num in
    partialResult + num
}
print(sumArr)

//allSatisfy 元素是否都满足某个条件，返回布尔值

let isSatisfy = arr.allSatisfy { num in
    num > 0
}
print(isSatisfy)


//compactMap 与 map 的区别是？

let boolMapArr = array.map { str in
    str.starts(with: "A")
}
print(boolMapArr)

let boolCompactMapArr = array.compactMap { str in
    str.starts(with: "A")
}
print(boolCompactMapArr)


// mapValues 不改变原字典

let dict = ["first" : 1, "second" : 2, "third" : 3, "forth" : 4]
let mapDict = dict.mapValues { num -> String in
    "num-\(num)"
}
print(mapDict)

// compactMapValues 转化加过滤
let dict1 = ["first" : "1", "second" : "2", "third" : "3", "forth" : "4", "five" : "abc"]

let mapDict1 = dict1.compactMapValues { value in
     Int(value)
}
print(mapDict1)


let stringDict = ["one": "1", "two": "2", "three": "three", "four": "4"]

let intDict = stringDict.compactMapValues { Int($0) }
print(intDict)

let optionalDict = ["a": 1, "b": nil, "c": 3, "d": nil]

let nonOptionalDict = optionalDict.compactMapValues { $0 }
// 结果: ["a": 1, "c": 3]

let userData = [
    "Alice": "25",
    "Bob": "thirty",
    "Charlie": "30",
    "David": "N/A"
]

let ageData = userData.compactMapValues { value -> Int? in
    if value == "N/A" {
        return 0  // 特殊处理
    }
    return Int(value)
}
// 结果: ["Alice": 25, "Charlie": 30, "David": 0]
// "Bob" 被过滤掉了
