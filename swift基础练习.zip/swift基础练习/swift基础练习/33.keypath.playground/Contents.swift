import Cocoa

class Student :NSObject {
    @objc var name: String
    @objc var age: Int
    @objc var born_in: String
    @objc var sex: String
    init(name: String, age: Int, born_in: String, sex: String) {
        self.name = name
        self.age = age
        self.born_in = born_in
        self.sex = sex
    }
}
    
let stu = Student(name: "zhangsan", age: 12, born_in: "2009-10-12", sex: "男")
stu.age
stu.age = 10


let name = stu.value(forKey: "name")
stu.setValue(12, forKey: "age")

stu.value(forKeyPath: "age")


print(stu.age)
