import Cocoa

/**
 Swift中属性有多种
    存储属性:存储实例的常量和变量
    计算属性:通过某种方式计算出来的属性
    类属性:与整个类自身相关的属性
 
 总结:
     存储属性,最先被初始化
     构造方法,仅次于存储属性调用,可以在这里对存储属性进行赋值
     懒加载属性、类属性、全局属性都是在第一次使用的时候初治化一次,以后调用都不再初始化
     当懒加载属性是基于一个存储属性计算的时候,切勿使用懒力加载属性,采用计算属性
 */

class Student {
    // 懒加载，只有在使用的时候才加载到内存
    lazy var abc: String = {
        return "ABC"
    }()
    
    lazy var b: String = {
        return ""
    }()
    
    
    static let englishScore: Double = 90.0
    //存储属性
    var age: Int = 0
    var name: String? {
        // 属性监听
        willSet {
            print("即将赋值")
            if let newValue = newValue {
                print("newValue = \(newValue)")
            }
        }
        
        didSet {
            print("已赋值")
            if let oldValue = oldValue {
                print("oldValue = \(oldValue)")
            }
        }
    }
    var chineseScore: Double = 0.0
    var mathScore: Double = 0.0
    var _averageScore: Double = 0.0
    //计算属性
    var averageScore: Double {
        get {
            return (chineseScore + mathScore) * 0.5
        }
        
        //死循环,在内部又会调用set方法
        //newValue是系统分配的变量名,内部存储着新值
        set {
            _averageScore = newValue
        }
    }
    
    func eat() {
        print("eat = \(self.averageScore)")
    }
    
    // 可以用 class static 修饰类方法
    class func sleep() {
        
    }
    
    static func read() {
        
    }
    
}

let stu = Student()
stu.chineseScore = 90
stu.mathScore = 100
stu.eat()

//获取计算属性的值
print(stu.averageScore)

print(Student.englishScore)

stu.name = "xiefei"
//stu.name = "zhangsan"


/**
 class和static相同点
     。可以修饰方法,static修饰的方法叫做静态方法,class修饰的叫做类方法
     。都可以修饰计算属性
 class和static不同点
     。class不能修饰存储属性,static可以修饰存储属性,static修饰的存储属性称为静态变量(常量)
     。class修饰的计算属性可以被重写,static修饰的不能被重写
     。class修饰的类方法可以被重写，static修饰的静态方法不能被重写
     。class修饰的类方法被重写时,可以使用static让方法变为静态方法
     。class修饰的计算属性被重写时,可以使用static让其变为静态属性,但它的子类就不能被重写了
     。class只能在类中使用,但是static可以在类,结构体,或者枚举中使用
 
 */
