import Cocoa

var array2 = ["A", "B", "C", "D", "E"]
 
var array3 = ["1", "2"]

var array4 = [1, 2]

let appendArr = array2 + array3
//let appendArr1 = array2 + array4 // 必须是同种类型相拼接
print(appendArr)

// 创建带有默认值的数组
var threeDoubles = Array(repeating: 2, count: 4)
print(threeDoubles)

func moveZeroes(_ nums: inout [Int]) {
        var noZeroArr = nums.filter{ (num)-> Bool in num != 0 }
        let zeroCount = nums.count - noZeroArr.count
        noZeroArr.append(contentsOf: Array(repeating: 0, count: zeroCount))
    }

