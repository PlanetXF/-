import Cocoa

 /**
  结构体：
  1. 结构体是由一系列具有相同类型或不同类型的数据构成的数据结构
  2. 结构体是值类型
  3. 结构体既可以定义属性又可以定义方法
  */

struct Student {
    var name = "zhangsan"
    var age = 18
    var sex = "男"
    
    func say () {
        print("学生会说话")
    }
}

let stu = Student(name: "xiefei", age: 23, sex: "男")
print(stu.name)
print(stu.age)
print(stu.sex)

/**
 值类型是一种当它被赋值给一个常量或者变量，或者被传递给函数时会被拷贝的类型
 swift中的结构体 （包括枚举）是值类型，它在代码传递中总是会被拷贝
 */

var stu3 = stu
stu3.age = 20
print(stu.age) // 23 更改stu3不会影响stu的值，说明值传递是拷贝

/**
 常见结构体
 */

public struct CGRect {
    public var origin:CGPoint // 坐标
    public var size:CGSize // 宽高
    public init() {
        self.origin = CGPoint(x: 0, y: 0)
        self.size = CGSize(width: 0, height: 0)
    }
    public init(origin:CGPoint,size:CGSize) {
        self.origin = origin
        self.size = size
    }
}

public struct CGSize{
    public var width: CGFloat
    public var height: CGFloat
    public init() {
        self.height = 0
        self.width = 0
    }
    public init(width:CGFloat,height:CGFloat) {
        self.width = width
        self.height = height
    }
}

public struct CGPoint {
    public var x: CGFloat
    public var y: CGFloat
    public init() {
        self.x = 0
        self.y = 0
    }
    public init(x:CGFloat,y:CGFloat) {
        self.x = x
        self.y = y
    }
}

/**
 Swift中的String,Array和Dictionary类型是作为结构体来实现的,这意味着String,Array和
 Dictionary在它们被赋值到一个新的常量或者变量,或它们本身被传递到一个函数或方法中的时候,其实
 是传递了拷贝。
 
 OC中的NSString,NSArray和NSDictionary,它们是作为类来实现的,所以NSString,NSArray和
 NSDictionary实例总是作为一个引用而不是拷贝来赋值和传递。
 */


