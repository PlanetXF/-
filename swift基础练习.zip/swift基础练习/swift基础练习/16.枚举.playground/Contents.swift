import Cocoa

enum Method: Int {
    case Add = 1
    case Sub
    case Mul
    case Div
}

let a = Method.Add
let aRawValue = Method.Add.rawValue
print(a)

// 构造枚举元素
let m = Method(rawValue: 3)
if let m = m {
    print("m- \(m)")
}



enum Compass {
    case North, South, East, West
}

let b = Compass.East

switch b {
case .East:
    
    break
default:
    print("A")
}

