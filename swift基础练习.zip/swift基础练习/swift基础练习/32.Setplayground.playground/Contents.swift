import Cocoa

let num = 10
num.hashValue

let str = "str"
str.hashValue

let emptySet: Set<String> = Set()
let emptySet1 = Set<String>([])

type(of: emptySet)

let strSet1 = Set(["1", "2", "3"])
print(strSet1) // ["3", "2", "1"]  无序集合

let strSet2 = Set(["1", "1", "2"])
print(strSet2) // ["1", "2"] 自动忽略重复值，不允许重复

var varStrSet = Set<String>()
varStrSet.insert("allen")
print(varStrSet)

varStrSet.remove("allen")
print(varStrSet)

varStrSet = []

varStrSet.insert("allen")
varStrSet.insert("kate")
varStrSet.insert("bob")

for item in varStrSet.sorted() {
    print(item)
}

print(varStrSet.count)

varStrSet.isEmpty

varStrSet.contains("bob")
varStrSet.contains("Jim")

var intSetA = Set([1, 2, 3])
var intSetB = Set([2, 3, 4, 5, 6])

let res1 = intSetA.intersection(intSetB)
print(res1) // [2, 3]交集

let res2 = intSetA.subtracting(intSetB)
print(res2) //  [1] 差集

let res3 = intSetA.symmetricDifference(intSetB)
print(res3) // [1, 5, 4, 6] 对称差集

let res4 = intSetA.union(intSetB)
print(res4) //  [1, 3, 5, 2, 4, 6] 并集
