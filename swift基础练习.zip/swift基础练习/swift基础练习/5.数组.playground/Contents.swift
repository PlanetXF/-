import Cocoa

var array1: [Int] = [Int]()

array1.isEmpty // 判空

var array: Array<Int> = [1, 2, 3, 4]

var array2: [String] = ["A", "B", "C", "D"]

array2.count // 数组长度


array1.append(123) // 改变原数组 加入元素
//print(array1)

array2.insert("E", at: 2)
//print(array2)

array2.removeLast() // 改变原始数组，返回取出的值
//print(array2)

let dropArr = array2.dropLast() // 不改变原数组，返回一个新数组
//print("dropArr = \(dropArr)")

var empty: [Int] = []

// dropLast 安全
let safe = empty.dropLast() // 返回空数组

// removeLast 危险
if !empty.isEmpty {         // 必须检查
    empty.removeLast()      // 否则会崩溃
}


array2.reverse() // 反转（倒序）数组, 改变原始数组
//print(array2)








