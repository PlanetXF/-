//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

let numbers = [1, 2, 3, 4, 5]

let sum1 = numbers.reduce(0) { partialResult, item in
    partialResult + item
}
print("sum1", sum1)

let num2 = numbers.map { item in
    item * 2
}

print("num2", num2)


let numberStrs =  ["1", "2", "3", "4", "5", "a"]
let num3 = numberStrs.compactMap { item in
    Int(item)
}
print("num3", num3)

