import Cocoa

var array2 = ["A", "B", "C", "D", "E"]

for item in array2 {
    print(item)
}

for item in array2 {
    print(item)
}

//for item in array2 {
//    print(item)
//}

// 循环打印索引

// 元组的形式遍历
//for (index, item) in array2.enumerated() {
//    print("enumerated, \(index), \(item)")
//}
//
//for index in array2.indices {
//    print("indices, \(index), \(array2[index])")
//}
//
//for index in 0..<array2.count {
//    print("\(index), \(array2[index])")
//}
//
//for item in array2[0..<array2.count] {
//    print(item)
//}
//
//for item in array2[...] {
//    print(item)
//}
