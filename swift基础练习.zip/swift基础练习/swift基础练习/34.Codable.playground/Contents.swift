import Cocoa

let res = """
{
    "name": "Jone",
    "age": 17,
    "born_in": "China",
    "sex": "male" 
}
"""

struct Student: Codable {
    let name: String
    let age: Int
    let bornIn: String
    let sex: String
    
    enum CodingKeys: String, CodingKey {
        case name
        case age
        case bornIn = "born_in"
        case sex
    }
}

let decode = JSONDecoder()

if let data = res.data(using: .utf8) {
    let s: Student? = try? decode.decode(Student.self, from: data)
    if let s = s {
        print("\(s.age)-\(s.name)-\(s.sex)")
    }
    
    let encode = JSONEncoder()
    if let codeData = try? encode.encode(s), let str = String(data: codeData, encoding: .utf8) {
        print(str)
    }
   
}


 

