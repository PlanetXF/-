import Cocoa

protocol BuyTicketProtocol {
    func buyTicket()
}

//2.让具体的类或者结构体实现协议,将任务具体化
class Assist : BuyTicketProtocol{
    func buyTicket() {
        print("助手去买票")
    }
}
class HN : BuyTicketProtocol{
    func buyTicket(){
        print("黄牛去买票")
    }
}

class Boss {
    var delegate: BuyTicketProtocol?
    func buy() {
        delegate?.buyTicket()
    }
}

let a = Assist()
let b = Boss()
b.delegate = a
b.buy()


