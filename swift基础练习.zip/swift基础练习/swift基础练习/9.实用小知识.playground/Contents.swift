import Cocoa

let number1 = 10

// 判断一个数是否是另一个数的倍数
if number1.isMultiple(of: 2) {
    print("偶数")
} else {
    print("奇数")
}

// 随机数

let ranInt = Int.random(in: 0..<10)
print(ranInt)

let ranFloat = Float.random(in: 0..<10)
print(ranFloat)

let ranBool = Bool.random()
print(ranBool)

// 数组打乱

let names = ["zhangsan", "lisi", "wangwu"]
let shuffledNames = names.shuffled()
print(shuffledNames)

// 布尔转换
var isSwift = false
isSwift.toggle()
print(isSwift) 
