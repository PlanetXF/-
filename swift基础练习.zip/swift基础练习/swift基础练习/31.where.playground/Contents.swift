import Cocoa

/**
 switch case
 */
let names = ["王小二", "张三", "李四", "王五"]

for name in names {
    switch name {
    case let x where x.hasPrefix("王"):
        print("x - \(x)")
    default:
        print("你好，\(name)")
    }
}

/**
 for循环中
 */
let array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

for item in array where item % 2 == 0 {
    print(item)
}


let arr = array.filter { $0 % 2 == 0 }.forEach { print($0) }



class AA {
    
}

protocol A {
    
}

extension A where Self: AA {
    func say() {}
}

class BB: A {
    
}

let b = BB()

class CC: AA, A {  // 只有AA的子类才能实现A协议里的方法
    override init() {
        super.init()
    }
}

let c = CC()
c.say()


