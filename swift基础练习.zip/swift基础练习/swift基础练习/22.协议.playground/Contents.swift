import Cocoa

protocol AA {
    var str: String { get set }
    func eat(food: String)
}

extension AA {
    func eat(food: String) {
        print("扩展吃\(food)")
    }
}


struct BB: AA {
    var str: String
    
    let name: String
    let age: String
}

let b = BB(str: "西瓜", name: "xf", age: "24")
b.eat(food: "apple")

