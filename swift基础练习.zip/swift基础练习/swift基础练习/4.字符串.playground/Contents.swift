import Cocoa

var str = "Hello, playground" // 可变字符串
let str1 = "Hello" // 不可变字符串


let longStr = """
此诗描写了旅居在外的抒情主人公秋日夜晚在屋内抬头望月而思念家乡的感受。前两句写主人公在作客他乡的特定环境中一刹那间所产
生的错觉；后两句通过动作神态的刻画，深化主人公的思乡之情。全诗运用比喻、衬托等手法，表达客居思乡之情，语言清新朴素而韵味
含蓄无穷，历来广为传诵
""" // 长字符串

print(longStr)

let c = #"字符串中有\转义字符\"#
print(c)

// 字符串拼接

var subStr1 = "Hello", subStr2 = " swift"
print(subStr1 + subStr2)
//subStr1.append(subStr2)
//print(subStr1)
print("\(subStr1)\(subStr2)")


for str in subStr1 {
    print(str)
}

// 能输出下标的方法
for (index, str) in subStr1.enumerated() {
    print("index = \(index) str = \(str)")
}

for index in subStr1.indices {
    let str = subStr1[index]
    print("index = \(index.utf16Offset(in: subStr1)) str = \(str)")
}


// 大小写

let a = "ABC"
print(a.lowercased().uppercased())

// 包含

print(a.contains("A"))

// 分割

let compnentsStr = "AA**BB**CC"
let splitStrs = compnentsStr.components(separatedBy: "**")
for (index, item) in splitStrs.enumerated() {
    print("\(index), \(item)")
}

// 替换
let replacedStr = compnentsStr.replacingOccurrences(of: "**", with: "$$")
print(replacedStr)

// **字串

let completeStr = "Hello World"

print(completeStr.prefix(5)) // 前缀
print(completeStr.suffix(5)) // 后缀

let indexStart = completeStr.index(completeStr.startIndex, offsetBy: 2)
let endStart = completeStr.index(completeStr.startIndex, offsetBy: 8)

let completeStrSubStr1 = completeStr[indexStart...endStart]
print(completeStrSubStr1)


// 获取指定元素的前一个元素的索引
let endIndex = completeStr.index(before: completeStr.index(completeStr.startIndex, offsetBy: 2))
print(completeStr[endIndex])
