import Cocoa

var name: String? = "zhangsan"

name = nil

// ！强制解包 不推荐


// 可选绑定 隐式解包
if let name = name {
    print(name)
}

// 守卫模式
guard let name = name else {  }
