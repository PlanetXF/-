import Cocoa

for item in 0..<10 {
    print(item)
}

for _ in 0..<10 {
    print("hello world")
}

var a = 10
while a < 20 {
    print(a)
    a += 4
}


var b = 10
repeat {
    print("swift")
    b += 5
} while b < 20

