import UIKit


var arr = [1, 2, 3, 4, 5, 9]
print(arr)

arr.forEach { item in
    print(item)
}

arr.sort(by: >)
arr.sort(by: <)
print(arr)

arr.shuffle()
print(arr)

var s1 = arr.reversed()
print(s1)

arr.reverse()
print(arr)

let line = "apple orange banana"
var l1 = line.split(separator: " ")
print(l1)

let line2 = "apple orange+banana"
var l2 = line2.split { character in
    character == " " || character == "+"
}
print(l2)

var fruits = ["apple", "pear", "grape", "peach", "banana"]
print(fruits.joined())
print(fruits.joined(separator: "+"))
