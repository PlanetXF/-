import Cocoa
/**
 类的实例是引用类型
 
 类与结构体的对比：
 
 相同点：
     定义属性
     定义方法
     定义构造函数(init函数)
     可以被扩展
     遵循协议
 
 类有而结构体没有的额外功能：
     继承
     类型转换(子类as父类)
     析构函数
     引用计数
 
 开发中类与结构体的使用场景
 类和结构体都可以用来定义自定义的数据类型,结构体实例总是通过值来传递,而类实例总是通过引用
 来传递。
 按照通用准则,当符合以下一条或多条情形时应考虑结构体,其他情请况下,使用类。大部分的自定义的
 数据结构应该是类,而不是结构体。
 
    。要描述的数据类型中只有少量的简单数据类型的属性
    。要描述的数据类型在数据传递时要以复制的方式进行
    。要描述的数据类型中所有的属性在进行传递时需要以复制的方式进行
    。不需要继承另一个数据类型
 
 比如:
    。定义几何形状的大小,封装了一个width属性和height属性,两者者为Double类型;
    。定义一定范围的路径,封装了一个start属性和length属性,两者为Int类型;
    。定义三维坐标系的一个点,封装了x,y和z属性,它们是Double类型。
 */

class Student {
    var name = "zhangsan"
    var age = 18
    var sex = "男"
    
    func say () {
        print("学生会说话")
    }
}

var stu = Student()
stu.age = 20
stu.name
stu.sex
stu.age
stu.say()

var stu2 = stu
stu2.age = 30
print(stu.age) // 值类型型拷贝引用

stu2 === stu // true
stu2 !== stu // false


class Vehicle {
    var currentSpeed = 0.0
    func makeNoise(){
        print("Ba Ba")
    }
}

//定义一个子类

class Bicycle: Vehicle {
    var hasBasket = false
    // 重写
    override func makeNoise() {
        print("Di Di")
    }
}

let b = Bicycle()
b.makeNoise()

