import Cocoa

// 计算一个数的平方

func square(num: Int) -> Int {
    return num * num
}

let result = square(num: 2)
print(result)

// 闭包改写：

let sq = {
    
    (num: Int) -> Int in
    
    return num * num
}

let sqReault = sq(3)

