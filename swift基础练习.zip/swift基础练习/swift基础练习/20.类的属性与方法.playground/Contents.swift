import Cocoa

struct Student {
    var str = "Hello, playground"
    
    mutating func eat() {
        self.str = "Hello swift"
    }
}

var stu = Student()
stu.eat()

// 不允许用let修饰

//let stu1 = Student()
//stu1.eat()
