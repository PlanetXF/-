import Cocoa

var greeting = "Hello, playground"

/**
 为现有的类、结构体、枚举、协议添加新的功能。扩展和OC中的分类类似
 扩展可以：
    添加计算属性
    定义方法
    提供新的构造函数
    使现有的类型遵循协议
 */

extension Int {
    var km: Int {
        return self * 1000
    }
    
    func square() -> Int {
        return self * self
    }
}

3.km
3.square()


