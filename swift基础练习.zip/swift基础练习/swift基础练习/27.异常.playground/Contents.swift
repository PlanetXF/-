import Cocoa

enum Ex: Error {
    case FileIsEmpty
    case FileIsNotFound
}

func readFile(path: String) throws -> String {
    if path.isEmpty {
        throw Ex.FileIsEmpty
    }
    
    if path != "/User/Desktop/" {
        throw Ex.FileIsNotFound
    }
    
    return "123"
}

do {
    try readFile(path: "abc")
} catch {
    print(error)
}

let result = try? readFile(path: "abc") // 出现了异常就返回nil
if let result = result {
    print(result)
}

/**
 defer关键字
 修饰函数内任意一段代码
 调用时机: 在函数中的其余代码都执行完毕,函数即将结束前
 可以用它在异常中进行扫尾工作,比如释放资源等
 */

do {
    defer {
        print("defer执行")
    }
    try readFile(path: "")
} catch {
    print(error)
}


