import Cocoa

var greeting = "Hello, playground"

var one = ("zhangsan", "男", 30, 178.5)
var two = (name: "zhangsan", sex: "男", age: 30, height: 178.5)

let (errorCode, errorInfo) = (404, "Not Found") // 类似js展开符

one.0 // 通过下标访问
two.name // 通过别名访问
