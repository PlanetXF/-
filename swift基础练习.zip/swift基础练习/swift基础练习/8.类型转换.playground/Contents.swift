import Cocoa

let age = 20

// 插值表达式
let str = "小明今年\(age)岁"

let str2 = "123"

let num2 = Int(str2)
print(num2!)

// is 类型检查操作符，来检查是个实例是否属于一个特定的子类。是true 不是false
// as 类型转换操作符，向下类型转换其子类型 不确定向下转换是否成功 as？否则 as！

// Any 是一个空协议集合的别名，它表示没有任何协议，因此它可以是任何类型，包括类实例与结构体实例。可以表示任何类型，包括函数类型
// AnyObject 是一个成员为空的协议，任何对象都实现了这个协议。可以表示任何类型的实例

let array: [Any] = [12, "zhangsan"]

let first = array.first

let last = array.last

let a = first as? Int

if let a = a {
    print(a)
}

let b = last as! String
print(b)




