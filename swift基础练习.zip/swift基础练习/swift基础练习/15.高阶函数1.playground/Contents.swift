import Cocoa

var array: [String] = ["A", "Baby", "Apple", "Google", "Aunt"]

let firstEle = array.first { $0.hasPrefix("A") } // 筛选集合中A打头的第一个元素

if let firstEle = firstEle {
    print(firstEle)
}

let lastEle = array.last { $0.hasPrefix("A") } // 筛选集合中A打头的最后一个元素
if let lastEle = lastEle {
    print(lastEle)
}

//removeAll 改变原数组

array.removeAll { $0.hasPrefix("A") }
print(array)

 
