import Cocoa

// 值类型构造函数委托
struct Size {
    var width = 0.0, height = 0.0
    
    init(){
        //构造函数委托
        self.init(width: 2.0, height: 2.0)
    }
    
    init(width: Double, height: Double){
        self.width = width
        self.height = height
    }
}
//要么不要写任何构造函数,要么全写所有的构造函数,否则下下面第二种调用方式会有问题,参考上面第四条
var size = Size()
size.width
size.height
    
var size2 = Size(width: 1.2, height: 1.2)
    
size2.width
size2.height


/**
 所有类的存储属性--包括从它的父类继承的所有属性都必须在在初始化期间分配初始值。
 Swift为类类型定义了两种构造函数以确保所有的存储属性接收一个初始值,它们就是
 
 指定构造函数(Designated Initializer)和
 便捷构造函数(Convenience Initializer)
 
 。指定构造函数是类的主要构造函数。指定构造函数可以初始化所有类引用的属性并且调用合适的父
 类构造函数来继续这个初始化过程给父类链
 
 。一个类通常只有一个指定构造函数并且每个类至少得有一个指定构造函数
 
 。便捷构造函数是次要的,可以在相同的类里定义一个便捷构造函数来调用一个指定构造函数给指定
 构造函数设置默认形式参数
 
 */


class Car {
    var speed: Float
    init(speed: Float) {
        self.speed = speed
    }
    
    convenience init() {
        self.init(speed: 120.0)
    }
}


class Bus: Car {
    var name: String
    init(name: String) {
        self.name = name
        // 一定要在子类属性初始话完毕之后再调用
        super.init(speed: 100.0)
    }
    
    convenience init() {
        self.init(name: "zhangsan")
    }
    
    deinit {
        print("资源释放")
    }
}

var bus: Bus? = Bus()
bus = nil

/**
 Swift会自动释放不再需要的实例以释放资源
 
 。Swift通过自动引用计数(ARC)处理实例的内存管理
 。当引用计数为0时,系统会自动调用析构函数(不可以手动调用)
 。通常在析构函数中释放一些资源(如移除通知等操作)
 
 */

