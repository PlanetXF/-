import Cocoa

var greeting = "Hello, playground"

/**
 
 获取对象类型:type(of:)语法
    元类型:可以理解为类型的类型,可以通过类型.Type定义,既然是是类型,就可以修饰变量或者常量,
    如何得到这种类型?需要通过类型.self
 
 */


class A {
    class func method () {
        print("Hello")
    }
}

A.method()

let a: A.Type = A.self // 获取元类型
a.method()

//

protocol Test {
    
}

let typeB: Test.Protocol = Test.self // 协议的元类型

// 这里 Self 在 MyClass 中就是 MyClass 类型
// 如果是子类调用，Self 会自动指代子类类型

class MyClass {
    // 返回自身类型的新实例
    func copy() -> Self {
        return type(of: self).init()
    }
    
    required init() {} // 确保有必要的初始化方法
}


// 这里 Self 会根据实际遵循协议的类型动态确定（如 Person 或它的子类）

protocol Clonable {
    func clone() -> Self
}

class Person: Clonable {
    func clone() -> Self { // 必须返回具体的Person类型
        return type(of: self).init()
    }
    required init() {}
}


