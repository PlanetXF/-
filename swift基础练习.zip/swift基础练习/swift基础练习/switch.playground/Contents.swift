import Cocoa

let a = 55

switch a {
case 0..<60:
    print("<60-\(a)")
    fallthrough // 可穿透
case 60..<65:
    print("<65-\(a)")
    break
case 65..<70:
    print("<70-\(a)")
    break
case 70..<75:
    print("<75-\(a)")
    break
default:
    break
}
