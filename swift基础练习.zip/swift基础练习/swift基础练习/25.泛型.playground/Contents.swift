import Cocoa

// 普通案例
func swapTwoInts(_ a: inout Int, _ b: inout Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}
var oneInt = 3
var twoInt = 4
swapTwoInts(&oneInt, &twoInt)
print(oneInt,twoInt)

func swapTwo<T>(_ a: inout T, _ b: inout T) {
    let temporaryA = a
    a = b
    b = temporaryA
}

swapTwo(&oneInt, &twoInt)
print(oneInt,twoInt)

protocol myProtocol {
    associatedtype Element
    
    func say(a: Element)
}

struct A: myProtocol {
    func say(a: String) {
        print("吃了\(a)")
    }
    
    typealias Element = String
}

let a = A()
a.say(a: "馕")

