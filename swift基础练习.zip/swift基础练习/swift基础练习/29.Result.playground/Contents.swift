import Cocoa

let url = URL(string: "")
var request: URLRequest

if let url = url {
    request = URLRequest(url: url)

    URLSession.shared.dataTask(with: request) { data, respones, error in
        if error != nil {
            // 处理error
        } else {
            // 处理数据data
        }
    }
}


public enum Result<Success, Failure> where Failure: Error {
    case success(Success)
    case failure(Failure)
}

enum FileReadError : Error {
    case FileISNull
    case FileNotFound
}

//2.改进方法,让方法抛出异常
func readFileContent(filePath : String) -> Result<String, FileReadError> {
    //1.filePath为""
    if filePath == ""{
        return .failure(.FileISNull)
    }
    //2.filepath有值,但是没有对应的文件
    if filePath != "/User/Desktop/123.plist" {
        return .failure(.FileNotFound)
    }
    
    //3.取出其中的内容
    return .success("123")
}

let result = readFileContent(filePath: "")

switch result {
case .failure(let error):
    print(error)
    break
case .success(let content):
    print(content)
    break
default:
    print("")
}


/**
 错误处理
 */

enum NetworkError: Error {
    case URLInvalid
}

func getInfo(from urlString: String, completionHandler: @escaping (Result<String, NetworkError>) -> Void ) {
    if urlString.hasPrefix("https://") {
        let data = "respose result"
        completionHandler(.success(data))
    }
    
    else {
        completionHandler(.failure(.URLInvalid))
    }
}

getInfo(from: "https://www.baidu.com") { result in
    switch result {
    case .failure(let error):
        print("")
    case .success(let content):
        print(content)
    }
}



