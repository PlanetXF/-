import Cocoa

var greeting = "Hello, playground"

let a = 10, b = 20


// 区间运算符

print(0...5)

let d = Int8.max // 取Int8最大值
let e = Int8.min // 取Int8最小值

print(a == b)
print(greeting)
