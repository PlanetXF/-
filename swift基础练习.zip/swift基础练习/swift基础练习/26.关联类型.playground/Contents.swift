import Cocoa

/**
 关联类型通过associatedtype关键字指定
 Element起到了占位符的作用,指示了某种类型
 在实现的时候不能直接用Element
 Element在遵守协议中协议方法中明确泛型的类型
 */

protocol SomeProtocol{
    associatedtype Element
    func method1(element:Element)
    func method2(element:Element)
}

struct TestStruct: SomeProtocol {
    
    func method1(element: String){
        print("method1: \(element)")}
   
    func method2(element: String){
        print("method2: \(element)")
    }
}

TestStruct().method1(element: "Hello")
TestStruct().method2(element:"World")


protocol AA {
    associatedtype Element
    func method1(element: Element)
    func method1() -> Element
}
