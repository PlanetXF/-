//
//  AppDelegate.h
//  EventPassed
//
//  Created by 谢飞 on 2025/8/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

