//
//  CustomButton.h
//  EventPassed
//
//  Created by 谢飞 on 2025/8/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CustomButton : UIButton

@end

NS_ASSUME_NONNULL_END
