//
//  ViewController.m
//  EventPassed
//
//  Created by 谢飞 on 2025/8/24.
//

#import "ViewController.h"
#import "CustomButton.h"

@interface ViewController ()

@property(nonatomic, strong) CustomButton *cornerButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _cornerButton = [[CustomButton alloc] initWithFrame:CGRectMake(100, 100, 120, 120)];
    _cornerButton.backgroundColor = [UIColor blueColor];
    [_cornerButton addTarget:self action:@selector(doAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_cornerButton];
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)doAction:(id)sender
{
    NSLog(@"click");
}

@end
