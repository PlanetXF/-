//
//  SceneDelegate.h
//  EventPassed
//
//  Created by 谢飞 on 2025/8/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

