//
//  GroupObject.h
//  Group
//
//  Created by 谢飞 on 2025/8/30.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GroupObject : NSObject

@end

NS_ASSUME_NONNULL_END
