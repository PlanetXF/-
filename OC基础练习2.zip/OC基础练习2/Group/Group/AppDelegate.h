//
//  AppDelegate.h
//  Group
//
//  Created by 谢飞 on 2025/8/30.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

