//
//  UserCenterTest.m
//  GCD多读单写
//
//  Created by 谢飞 on 2026/5/30.
//

#import "UserCenterTest.h"

@interface UserCenterTest()

@property(nonatomic, strong) dispatch_queue_t concurrentQueue;
@property(nonatomic, strong) NSMutableDictionary *userDic;

@end

@implementation UserCenterTest

- (instancetype)init
{
    if (self = [super init]) {
        _concurrentQueue = dispatch_queue_create("read_write_queue", DISPATCH_QUEUE_CONCURRENT);
        _userDic = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (id)objectForKey: (NSString *)key
{
    __block id obj;
    dispatch_sync(self.concurrentQueue, ^{
        obj = [self.userDic objectForKey:key];
    });
    return obj;
}

- (void)setObject:(id)obj forKey:(NSString *)key
{
    dispatch_barrier_async(self.concurrentQueue, ^{
        [self.userDic setObject:obj forKey:key];
    });
}

@end
