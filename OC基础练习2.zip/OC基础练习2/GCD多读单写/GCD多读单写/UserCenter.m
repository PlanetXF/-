//
//  UserCenter.m
//  GCD多读单写
//
//  Created by 谢飞 on 2026/5/28.
//

#import "UserCenter.h"
@interface UserCenter()

@property(nonatomic, strong) dispatch_queue_t concurrentQueue;
@property(nonatomic, strong) NSMutableDictionary *userCenterDic;

@end

@implementation UserCenter

- (instancetype)init
{
    self = [super init];
    if (self) {
        _concurrentQueue = dispatch_queue_create("read_write_queue", DISPATCH_QUEUE_CONCURRENT);
        _userCenterDic = [[NSMutableDictionary alloc] init];
    }
    return self;
}
 
- (id)objecForKey:(NSString *)key
{
    __block id obj;
    // 读操作需要返回值，所以必须用 dispatch_sync（同步）
    // 如果用了异步，函数没等队列执行完就 return 了，你拿到的永远是 nil。
    dispatch_sync(self.concurrentQueue, ^{
        obj = [self.userCenterDic objectForKey:key];
    });
    return obj;
}

- (void)setObject:(id)obj forKey:(NSString *)key
{
    // 它提交的任务会等待它之前提交到队列的所有任务（读或写）全部执行完毕。
    // 然后独占队列执行自己的任务（写）。
    // 执行完后，队列恢复正常并发模式。
    dispatch_barrier_async(self.concurrentQueue, ^{
        [self.userCenterDic setObject:obj forKey:key];
    });
}

@end
