//
//  SceneDelegate.h
//  GCD多读单写
//
//  Created by 谢飞 on 2026/5/28.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

