//
//  AppDelegate.h
//  GCD多读单写
//
//  Created by 谢飞 on 2026/5/28.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

