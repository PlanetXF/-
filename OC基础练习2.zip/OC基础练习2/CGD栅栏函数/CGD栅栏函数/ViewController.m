//
//  ViewController.m
//  CGD栅栏函数
//
//  Created by 谢飞 on 2025/8/31.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    // 创建一个并发队列
    dispatch_queue_t queue = dispatch_queue_create("谢飞", DISPATCH_QUEUE_CONCURRENT);
    
    // 栅栏函数对 dispatch_get_global_queue 这种创建的函数失效，全局并发队列会自动对其降级。dispatch_barrier_async 只对自定义的并发队列有效。
//    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    
    dispatch_async(queue, ^{
        for (int i=0; i<5; i++) {
            NSLog(@"%d -- %@", i, [NSThread currentThread]);
        }
    });
    
    dispatch_async(queue, ^{
        for (int i=5; i<10; i++) {
            NSLog(@"%d -- %@", i, [NSThread currentThread]);
        }
    });
    
    // 可以阻碍后续的执行
    dispatch_barrier_sync(queue, ^{
        NSLog(@"这是一个栅栏函数");
    });
    
    NSLog(@"我在栅栏函数之后执行"); // 如果是同步栅栏函数，会阻碍这行代码，如果是异步栅栏函数就不会阻碍这行代码
    
    dispatch_async(queue, ^{
        for (int i=10; i<15; i++) {
            NSLog(@"%d -- %@", i, [NSThread currentThread]);
        }
    });
    
    
}


@end
