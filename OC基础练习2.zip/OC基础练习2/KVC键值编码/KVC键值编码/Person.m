//
//  Person.m
//  KVC键值编码
//
//  Created by 谢飞 on 2025/6/28.
//

#import "Person.h"

@implementation Person


- (instancetype)init
{
    if (self = [super init]) {
        _name = @"xf";
    }
    return self;
}

@end
