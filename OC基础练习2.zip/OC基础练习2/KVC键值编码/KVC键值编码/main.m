//
//  main.m
//  KVC键值编码
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Person *p = [[Person alloc] init];
//        p.name = @"xf";
        [p setValue:@"xf" forKey:@"name"];
        NSLog(@"%@", [p valueForKey:@"name"]);
        
        NSDictionary *dict = @{
            @"idNumber": @"1234",
            @"name": @"xiefei",
            @"age": @2
        };
        
        [p setValuesForKeysWithDictionary:dict];
        NSLog(@"%@", p.idNumber);
        NSLog(@"%@", p.name);
        NSLog(@"%d", p.age);
    }
    return 0;
}
