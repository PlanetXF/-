//
//  Person.h
//  KVC键值编码
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

@property(nonatomic, copy, readonly) NSString *name;
@property(nonatomic, copy) NSString *idNumber;
@property(nonatomic, assign) int age;

@end

NS_ASSUME_NONNULL_END
