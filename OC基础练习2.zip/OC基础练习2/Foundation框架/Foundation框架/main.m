//
//  main.m
//  Foundation框架
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        CGPoint point = CGPointMake(200, 200);
        CGSize size = CGSizeMake(200, 200);
        CGRect rect = CGRectMake(0, 0, 200, 200); // frame
        
        
        // NSValue
        NSNumber *number = [NSNumber numberWithInt:20];
        [number intValue];
        
        NSValue *value1 = [NSValue valueWithPoint:point];
        NSValue *value2 = [NSValue valueWithSize:size];
        NSValue *value3 = [NSValue valueWithRect:rect];
        
        NSArray *array = @[value1, value2, value3];
        
        // NSDate
        NSDate *date = [[NSDate alloc] init];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        
        // yyyy
        
        formatter.dateFormat = @"yyyy MM dd HH:mm:ss";
        NSLog(@"%@", [formatter stringFromDate:date]);
        
    }
    return 0;
}
