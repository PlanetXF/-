//
//  UserCenter.m
//  GCD
//
//  Created by 谢飞 on 2025/8/28.
//

#import "UserCenter.h"


// 多读单写的实现
@interface UserCenter ()

// 定义一个并发队列
@property(nonatomic, strong) dispatch_queue_t concurrent_queue;

// 用户数据中心，可能多个线程需要数据访问
@property(nonatomic, copy) NSMutableDictionary *userCenterDic;

@end

@implementation UserCenter

- (instancetype)init
{
    if (self = [super init]) {
        // 通过宏定义DISPATCH_QUEUE_CONCURRENT创建一个并发队列
        _concurrent_queue = dispatch_queue_create("read_write_queue", DISPATCH_QUEUE_CONCURRENT);
        // 创建数据容器
        _userCenterDic = [NSMutableDictionary dictionary];
    }
    return self;
}

- (id)objectForKey:(NSString *)key
{
    __block id obj;
    // 同步读取指定数据
    dispatch_sync(_concurrent_queue, ^{
        obj = [_userCenterDic objectForKey:key];
    });
    return obj;
}

- (void)setObject:(id)obj forKey:(NSString *)key
{
    // 异步栅栏调用设置数据
    dispatch_barrier_async(_concurrent_queue, ^{
        [_userCenterDic setObject:obj forKey:key];
    });
}

@end
