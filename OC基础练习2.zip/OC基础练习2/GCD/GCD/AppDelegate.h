//
//  AppDelegate.h
//  GCD
//
//  Created by 谢飞 on 2025/8/28.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

