//
//  ViewController.h
//  CGD延时
//
//  Created by 谢飞 on 2025/8/31.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

