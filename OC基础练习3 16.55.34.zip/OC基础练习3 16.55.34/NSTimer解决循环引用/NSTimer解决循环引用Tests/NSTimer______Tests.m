//
//  NSTimer______Tests.m
//  NSTimer解决循环引用Tests
//
//  Created by 谢飞 on 2026/6/2.
//

#import <XCTest/XCTest.h>

@interface NSTimer______Tests : XCTestCase

@end

@implementation NSTimer______Tests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
