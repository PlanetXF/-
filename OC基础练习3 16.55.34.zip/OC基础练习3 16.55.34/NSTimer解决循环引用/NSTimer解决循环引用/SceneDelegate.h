//
//  SceneDelegate.h
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

