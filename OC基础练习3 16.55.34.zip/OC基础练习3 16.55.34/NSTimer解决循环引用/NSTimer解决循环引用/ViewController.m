//
//  ViewController.m
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import "ViewController.h"

@interface ViewController ()

@property(nonatomic, strong) NSTimer *timer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                  target:self
                                                selector:@selector(tick)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)tick {
    NSLog(@"tick");
}

- (void)dealloc {
    // 永远不会执行，就是因为循环引用
    [self.timer invalidate];
    NSLog(@"");
}






@end
