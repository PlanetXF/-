//
//  TimerWeakProxy2.m
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import "TimerWeakProxy2.h"

@interface TimerWeakProxy2()
@property(nonatomic, weak) id target;
@end

@implementation TimerWeakProxy2

+ (instancetype)proxyWithTarget:(id)target
{
    TimerWeakProxy2 *proxy = [TimerWeakProxy2 alloc];
    return proxy;
}

@end
