//
//  NSTimer1VCViewController.m
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import "NSTimer1VCViewController.h"

@interface NSTimer1VCViewController ()

@property(nonatomic, strong) NSTimer *timer;

@end

@implementation NSTimer1VCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 解决方案一：iOS 10+ Block API（最推荐）
    
    __weak typeof(self) weakSelf = self;
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                 repeats:YES
                                                   block:^(NSTimer * _Nonnull timer) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf) {
                [strongSelf tick];
            }
    }];
}

- (void)tick {
    NSLog(@"tick");
}

- (void)dealloc {
    [self.timer invalidate];
}
@end
