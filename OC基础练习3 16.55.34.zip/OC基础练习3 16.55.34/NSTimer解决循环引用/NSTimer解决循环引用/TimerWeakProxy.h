//
//  TimerWeakProxy.h
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import <Foundation/Foundation.h>


@interface TimerWeakProxy : NSProxy

@property(nonatomic, weak, readonly) id target;

+ (instancetype)proxyWithTarget:(id)target;

@end



