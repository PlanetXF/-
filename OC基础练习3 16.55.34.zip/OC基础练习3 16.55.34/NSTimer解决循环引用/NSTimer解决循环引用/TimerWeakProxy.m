//
//  TimerWeakProxy.m
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import "TimerWeakProxy.h"

@interface TimerWeakProxy()
@property(nonatomic, weak) id target;
@end

@implementation TimerWeakProxy

+ (instancetype)proxyWithTarget:(id)target
{
    TimerWeakProxy *proxy = [TimerWeakProxy alloc];
    proxy.target = target;
    return proxy;
}

- (NSMethodSignature *)methodSignatureForSelector:(SEL)sel
{
    return [self.target methodSignatureForSelector:sel];
}

- (void)forwardInvocation:(NSInvocation *)invocation
{
    if (self.target) {
        [invocation invokeWithTarget:self.target];
    }
}

@end
