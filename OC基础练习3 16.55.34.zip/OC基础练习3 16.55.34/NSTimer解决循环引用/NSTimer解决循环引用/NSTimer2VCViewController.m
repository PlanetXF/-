//
//  NSTimer2VCViewController.m
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//
#import "TimerWeakProxy.h"
#import "NSTimer2VCViewController.h"

@interface NSTimer2VCViewController ()

@property(nonatomic, strong) NSTimer *timer;

@end

@implementation NSTimer2VCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // 中间代理对象（兼容 iOS 10 以下）
    // 创建代理
    TimerWeakProxy *proxy = [TimerWeakProxy proxyWithTarget:self];
    
    // timer 的 target 是 proxy 不是 self
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                  target:self
                                                selector:@selector(tick)
                                                userInfo:nil
                                                 repeats:YES];
}

- (void)tick
{
    NSLog(@"tick");
}

- (void)dealloc
{
    [self.timer invalidate];
    self.timer = nil;
    NSLog(@"");
}

@end
