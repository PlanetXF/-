//
//  NSTimer3VCViewController.m
//  NSTimer解决循环引用
//
//  Created by 谢飞 on 2026/6/2.
//

#import "TimerWeakProxy2.h"
#import "NSTimer3VCViewController.h"

@interface NSTimer3VCViewController ()

@property(nonatomic, strong) NSTimer *timer;

@end

@implementation NSTimer3VCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    if (@available(iOS 10.0, *)) {
        __weak typeof(self) weakSelf = self;
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                     repeats:YES
                                                       block:^(NSTimer * _Nonnull timer) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf) {
                [strongSelf tick];
            }
        }];
    } else {
        TimerWeakProxy2 *proxy = [TimerWeakProxy2 proxyWithTarget:self];
        self.timer = [NSTimer scheduledTimerWithTimeInterval:1.0
                                                      target:proxy
                                                    selector:@selector(tick)
                                                    userInfo:nil
                                                     repeats:YES];
    }
}

- (void)tick
{
    NSLog(@"");
}

@end
