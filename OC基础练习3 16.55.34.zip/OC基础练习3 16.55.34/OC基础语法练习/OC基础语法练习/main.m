//
//  main.m
//  OC基础语法练习
//
//  Created by 谢飞 on 2025/6/19.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 在这里创建自动释放对象
        NSLog(@"Hello, World!");
        // 代码块结束时，池中所有对象会收到release（释放）消息
        
        int a = 10;
        NSLog(@"%d", a);
        
        double b = 10.1;
        NSLog(@"%f", b);
        
        BOOL c = false;         NSLog(@"%hhd", c);
        
        NSString *name = @"张三";
        int age = 25;
        NSLog(@"用户信息：姓名=%@，年龄=%d", name, age);
        
        NSString *str = @"Hello OC";
        NSLog(@"%@", str);
        
    }
    return 0;
}
