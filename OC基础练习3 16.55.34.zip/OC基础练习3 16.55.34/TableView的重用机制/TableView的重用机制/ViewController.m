//
//  ViewController.m
//  TableView的重用机制
//
//  Created by 谢飞 on 2025/8/13.
//

#import "ViewController.h"
#import "IndexedTableView.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate, IndexedTableViewDataSource>

@property(nonatomic, strong) IndexedTableView *tableView; // 带有索引条的tableView
@property(nonatomic, strong) UIButton *button;
@property(nonatomic, copy) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _tableView = [[IndexedTableView alloc] initWithFrame:CGRectMake(0, 60, self.view.frame.size.width, self.view.frame.size.height - 60) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    // 设置table的索引数据源
    _tableView.indexedDataSource = self;
    
    [self.view addSubview:_tableView];
    
    // 创建一个按钮
    _button = [[UIButton alloc] initWithFrame:CGRectMake(0, 20, self.view.frame.size.width, 40)];
    _button.backgroundColor = [UIColor redColor];
    [_button setTitle:@"reloadTable" forState:UIControlStateNormal];
    [_button addTarget:self action:@selector(doAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_button];
    
    // 数据源
    _dataSource = [NSMutableArray array];
    for(int i=0; i<100; i++) {
        [_dataSource addObject:@(i+1)];
    }
}

- (NSArray<NSArray *> *)indexTitlesForIndexTableView:(UITableView *)tableView
{
    // 奇数次调用返回6个字母，偶数次调用返回11个
    static BOOL change = NO;
    
    if (change) {
        change = NO;
        return @[@"A", @"B", @"C", @"D", @"E", @"F", @"G", @"H", @"I", @"J", @"K"];
    } else {
        change = YES;
        return @[@"A", @"B", @"C", @"D", @"E", @"F"];
    }
    
}

#pragma mark UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_dataSource count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"reusedId";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    // 如果重用池中没有可重用的cell，那么创建一个cell
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    // 文案设置
    cell.textLabel.text = [[_dataSource objectAtIndex:indexPath.row] stringValue];
    
    return cell;
}

#pragma mark UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (void)doAction:(id)sender
{
    NSLog(@"reloadData");
    [_tableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}


@end
