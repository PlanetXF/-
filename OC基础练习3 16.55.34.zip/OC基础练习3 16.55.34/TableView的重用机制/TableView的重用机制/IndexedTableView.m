//
//  IndexedTableView.m
//  TableView的重用机制
//
//  Created by 谢飞 on 2025/8/13.
//

#import "IndexedTableView.h"
#import "ViewReusePool.h"

@interface IndexedTableView ()

@property(nonatomic, strong) UIView *containerView;
@property(nonatomic, strong) ViewReusePool *reusePool;

@end

@implementation IndexedTableView

- (void)reloadData
{
    [super reloadData];
    
    // 懒加载
    if (_containerView == nil) {
        _containerView = [[UIView alloc] initWithFrame:CGRectZero];
        _containerView.backgroundColor = [UIColor whiteColor];
        
        // 把字母索引条视图插入到最上面，避免索引条跟着table滚动
        [self.superview insertSubview:_containerView aboveSubview:self];
    }
    
    if (_reusePool == nil) {
        _reusePool = [[ViewReusePool alloc] init];
    }
    
    // 标记所有视图为可重用状态
    [_reusePool reset];
    
    //reload字母索引条
    [self reloadIndexedBar];
}

- (void)reloadIndexedBar
{
    // 获取字母索引条的现实内容
    NSArray <NSArray *> *arrayTitles = nil;
    if ([self.indexedDataSource respondsToSelector:@selector(indexTitlesForIndexTableView:)]) {
        arrayTitles = [self.indexedDataSource indexTitlesForIndexTableView:self];
    }
    
    // 判断字母索引条是否为空
    if (!arrayTitles || arrayTitles.count <= 0) {
        [_containerView setHidden:YES];
        return;
    }
    
    NSInteger count = arrayTitles.count;
    CGFloat buttonWidth = 60;
    CGFloat buttonHeight = self.frame.size.height / count;
    
    for (int i = 0; i < [arrayTitles count]; i++) {
        NSString *title = [arrayTitles objectAtIndex:i];
        // 从重用池中取出一个Button出来
        UIButton *button = (UIButton *)[_reusePool dequeueReuseableView];
        
        // 如果没有可重用的Button重新创建一个
        if (button == nil) {
            button = [[UIButton alloc] initWithFrame:CGRectZero];
            button.backgroundColor = [UIColor whiteColor];
            // 注册button到重用池当中
            [_reusePool addUsingView:button];
            NSLog(@"新创建了一个button");
        }
        else {
            NSLog(@"Button重用了");
        }
        
        // 添加button到父视图控件
        [_containerView addSubview:button];
        [button setTitle:title forState:UIControlStateNormal];
        [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        
        //设置button的坐标
        [button setFrame:CGRectMake(0, i * buttonHeight, buttonWidth, buttonHeight)];
        
        [_containerView setHidden:NO];
        _containerView.frame = CGRectMake(self.frame.origin.x + self.frame.size.width - buttonWidth, self.frame.origin.y, buttonWidth, self.frame.size.height);
    }
}


@end
