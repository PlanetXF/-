//
//  SceneDelegate.h
//  TableView的重用机制
//
//  Created by 谢飞 on 2025/8/13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

