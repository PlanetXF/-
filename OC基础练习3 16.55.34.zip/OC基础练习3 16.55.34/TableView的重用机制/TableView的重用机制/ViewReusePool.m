//
//  ViewReusePool.m
//  TableView的重用机制
//
//  Created by 谢飞 on 2025/8/13.
//

#import "ViewReusePool.h"

@interface ViewReusePool ()

// 等待使用的队列
@property(nonatomic, strong) NSMutableSet *waitUsedQueue;
// 使用中的队列
@property(nonatomic, strong) NSMutableSet *usingQueue;

@end

@implementation ViewReusePool

- (instancetype)init
{
    if (self = [super init]) {
        _waitUsedQueue = [NSMutableSet set];
        _usingQueue = [NSMutableSet set];
    }
    return self;
}

- (UIView *)dequeueReuseableView
{
    UIView *view = [_waitUsedQueue anyObject];
    if (view == nil) {
        return nil;
    } else {
        // 进行队列的移动
        [_waitUsedQueue removeObject:view];
        [_usingQueue addObject:view];
        return view;
    }
}

 
- (void)addUsingView:(UIView *)view
{
    if (view == nil) {
        return;
    }
    // 添加视图到使用中的队列
    [_usingQueue addObject:view];
}

- (void)reset
{
    UIView *view = nil;
    while ((view = [_usingQueue anyObject])) {
        // 从使用中的队列移除
        [_usingQueue removeObject: view];
        // 加入到等待使用的队列
        [_waitUsedQueue addObject: view];
    }
}


@end
