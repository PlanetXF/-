//
//  ViewReusePool.h
//  TableView的重用机制
//
//  Created by 谢飞 on 2025/8/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewReusePool : NSObject

// 从重用池中取出一个可重用的view
- (UIView *)dequeueReuseableView;
// 向重用池中添加一个视图
- (void)addUsingView:(UIView *)view;
// 重置方法，将当前使用中的视图移动到可重用队列当中
- (void)reset;


@end

NS_ASSUME_NONNULL_END
