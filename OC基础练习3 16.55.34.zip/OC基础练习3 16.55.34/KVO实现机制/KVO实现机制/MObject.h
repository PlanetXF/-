//
//  MObject.h
//  KVO实现机制
//
//  Created by 谢飞 on 2025/7/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MObject : NSObject

@property (nonatomic, assign) int value;

- (void)increase;

@end

NS_ASSUME_NONNULL_END
