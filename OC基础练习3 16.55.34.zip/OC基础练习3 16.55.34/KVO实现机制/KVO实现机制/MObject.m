//
//  MObject.m
//  KVO实现机制
//
//  Created by 谢飞 on 2025/7/27.
//

#import "MObject.h"

@implementation MObject

- (instancetype)init
{
    if (self = [super init]) {
        _value = 0;
    }
    return self;
}

//- (void)setValue:(int)value
//{
//    NSLog(@"%d", value);
//}

- (void)increase
{
    // 增加willChangeValueForKey didChangeValueForKey可以模拟KVO 即就是手动kvo
    [self willChangeValueForKey:@"value"];
    _value += 1;
    [self didChangeValueForKey:@"value"];
}

@end
