//
//  ViewController.m
//  KVO实现机制
//
//  Created by 谢飞 on 2025/7/27.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
