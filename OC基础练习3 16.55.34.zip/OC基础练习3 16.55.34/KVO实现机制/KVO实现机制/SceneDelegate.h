//
//  SceneDelegate.h
//  KVO实现机制
//
//  Created by 谢飞 on 2025/7/27.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

