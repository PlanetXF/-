//
//  ViewController.m
//  NSThread的使用
//
//  Created by 谢飞 on 2025/8/31.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSLog(@"%@",  [NSThread currentThread]);
    
    [NSThread detachNewThreadWithBlock:^{
        for (int i=0; i<5; i++) {
            NSLog(@"%i--%@", i, [NSThread currentThread]);
        }
    }];
    
    [NSThread detachNewThreadSelector:@selector(runThread) toTarget:self withObject:nil];
}

- (void)runThread
{
    for (int i=5; i<10; i++) {
        NSLog(@"%i--%@", i, [NSThread currentThread]);
    }
}


@end
