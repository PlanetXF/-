//
//  ViewController.m
//  NSThread的使用2
//
//  Created by 谢飞 on 2025/8/31.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([NSThread isMainThread]) {
        NSLog(@"%s 主线程", __func__);
    }
    
    [self targetActionMethod];
    [self blockMethod];
}

- (void)targetActionMethod
{
    // 创建线程
    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(runThread) object:nil];
    
    thread.name = @"谢飞";
    // 开启线程
    [thread start];
}

- (void)runThread
{
    if ([NSThread isMainThread]) {
        NSLog(@"%s 主线程", __func__);
    }
    for (int i=5; i<10; i++) {
        [NSThread sleepForTimeInterval:1.0];
        NSLog(@"%i--%@", i, [NSThread currentThread]);
    }
}

- (void)blockMethod
{
    NSThread *thread = [[NSThread alloc] initWithBlock:^{
        for (int i=0; i<5; i++) {
            [NSThread sleepForTimeInterval:1.0];
            NSLog(@"%i--%@", i, [NSThread currentThread]);
        }
    }];
    
    thread.name = @"飞哥";
    
    [thread start];
}

@end
