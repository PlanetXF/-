//
//  SceneDelegate.h
//  NSOperation
//
//  Created by 谢飞 on 2025/8/30.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

