//
//  ViewController.m
//  NSOperation
//
//  Created by 谢飞 on 2025/8/30.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
//    queue.maxConcurrentOperationCount = 1;
    
    NSInvocationOperation *op1 = [[NSInvocationOperation alloc] initWithTarget:self selector:@selector(opRun) object:nil];
    
    [queue addOperation:op1];
    
    NSBlockOperation *op2 = [NSBlockOperation blockOperationWithBlock:^{
        for (int i = 5; i < 10; i ++) {
            [NSThread sleepForTimeInterval:1.0];
            NSLog(@"%d -- %@", i, [NSThread currentThread]);
        }
    }];
    
    [queue addOperation:op2];
    
    
}

- (void)opRun
{
    for (int i = 0; i < 5; i ++) {
        [NSThread sleepForTimeInterval:1.0];
        NSLog(@"%d -- %@", i, [NSThread currentThread]);
    }
}


@end
