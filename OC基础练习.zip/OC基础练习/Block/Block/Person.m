//
//  Person.m
//  Block
//
//  Created by 谢飞 on 2025/7/17.
//

#import "Person.h"

@implementation Person

- (void)eat:(NSString *)food sports:(NSString *)sports completionHandle:(void (^)(NSString *str))completionHandle
{
    NSLog(@"eat = %@", food);
    completionHandle(sports);
}

@end
