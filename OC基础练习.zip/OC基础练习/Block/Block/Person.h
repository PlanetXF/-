//
//  Person.h
//  Block
//
//  Created by 谢飞 on 2025/7/17.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject


- (void)eat:(NSString *)food sports:(NSString *)sports completionHandle:(void (^)(NSString *str))completionHandle;

@end

NS_ASSUME_NONNULL_END
