//
//  main.m
//  Block
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "Person.h"

typedef int(^Block)(int, int);

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 返回类型（^名称）(参数1类型，参数2类型) = ^(参数1类型 形参1，参数2类型 形参2)
        
//        int(^myBlock)(int, int) = ^(int a, int b) {
//            return a + b;
//        };
        
        // 可供block修改
        __block int number = 10;
        
        Block block = ^(int a, int b) {
            // block 内修改外部变量，需要在变量前加__block
            number = 20;
            return a + b;
        };
        
        int c = block(1, 2);
        NSLog(@"%d", c);

        // 快捷键：键盘敲出inline
        
        
        int(^myBlock)(int, int) = ^(int a, int b) {
            return a + b;
        };
        
        Person *child = [[Person alloc] init];
        [child eat:@"apple" sports:@"football" completionHandle:^(NSString * _Nonnull str) {
            NSLog(@"sports = %@", str);
        }];
        
    }
    return 0;
}
