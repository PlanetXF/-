//
//  NSString+Hello.h
//  分类
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Hello)

- (void)say;

@end

NS_ASSUME_NONNULL_END
