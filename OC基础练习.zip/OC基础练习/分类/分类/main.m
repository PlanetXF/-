//
//  main.m
//  分类
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "NSString+Hello.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSString *str = @"abc";
        [str say];
        
    }
    return 0;
}
