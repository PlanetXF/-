//
//  NSString+Hello.m
//  分类
//
//  Created by 谢飞 on 2025/6/28.
//

#import "NSString+Hello.h"

/**
 1. 扩展已有类的功能
 2. 模块化组织代码
 3. 为系统类添加便捷方法
 4. 分解复杂类实现
 5. 实现非正式协议(Informal Protocol)
 6. 关联对象(Associated Objects)
 7. 方法交换(Method Swizzling)
 注：不能添加实例变量
 */

@implementation NSString (Hello)

- (void)say
{
    NSLog(@"hello");
}

@end
