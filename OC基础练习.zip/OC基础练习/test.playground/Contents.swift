import UIKit




func count(startTime: String, endTime: String, stepLong: Int) -> Int {
    
    let distance = endTime - startTime
    
    let step = Int(ceil(distance / (stepLong * 60 * 1000)))
    
    return step
}

