import UIKit

var e = ["张三": "烩面", "李四": "拉面", "王五": "拌面"]
for (key, value) in e {
//    print(key, value)
}

for key in e.keys {
//    print(key)
}

for value in e.values {
//    print(value)
}

e.forEach { (key: String, value: String) in
    print(key, value)
}

e.forEach {
    print($0, $1)
}

print(e.randomElement())
