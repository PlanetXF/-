//
//  ObjectB1.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "ObjectB1.h"

@implementation ObjectB1

- (void)fetchData
{
    // 具体处理
}

@end
