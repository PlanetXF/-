//
//  BaseObjectA.h
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "BaseObjectB.h"
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseObjectA : NSObject

// 桥架模式的核心实现
@property(nonatomic, strong) BaseObjectB *objB;

// 获取数据
- (void)handle;

@end

NS_ASSUME_NONNULL_END
