//
//  BaseObjectB.h
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BaseObjectB : NSObject

- (void)fetchData;

@end

NS_ASSUME_NONNULL_END
