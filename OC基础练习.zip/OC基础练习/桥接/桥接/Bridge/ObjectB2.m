//
//  ObjectB2.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "ObjectB2.h"

@implementation ObjectB2

- (void)fetchData
{
  // B2具体实现
}

@end
