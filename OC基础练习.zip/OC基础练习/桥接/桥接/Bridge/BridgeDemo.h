//
//  BridgeDemo.h
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "BaseObjectA.h"
#import "BaseObjectB.h"
#import "ObjectA1.h"
#import "ObjectB1.h"

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BridgeDemo : NSObject

@end

NS_ASSUME_NONNULL_END
