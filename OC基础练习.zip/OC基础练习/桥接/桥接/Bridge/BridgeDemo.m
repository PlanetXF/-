//
//  BridgeDemo.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "BridgeDemo.h"

@interface BridgeDemo()

@property(nonatomic, strong)BaseObjectA *objA;

@end

@implementation BridgeDemo

- (void)fetch
{
    // 可以对ObjectA1 ObjectB1 进行排列组合式的替换，以达到解耦调用的效果
    _objA = [[ObjectA1 alloc] init];
    
    BaseObjectB *b1 = [[ObjectB1 alloc] init];
    _objA.objB = b1;
    
    [_objA handle];
}

@end
