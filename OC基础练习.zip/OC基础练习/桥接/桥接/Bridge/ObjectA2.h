//
//  ObjectA2.h
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "BaseObjectA.h"

NS_ASSUME_NONNULL_BEGIN

@interface ObjectA2 : BaseObjectA

@end

NS_ASSUME_NONNULL_END
