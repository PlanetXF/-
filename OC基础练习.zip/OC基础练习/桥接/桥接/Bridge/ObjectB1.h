//
//  ObjectB1.h
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//
#import "BaseObjectB.h"

NS_ASSUME_NONNULL_BEGIN

@interface ObjectB1 : BaseObjectB

@end

NS_ASSUME_NONNULL_END
