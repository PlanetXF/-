//
//  BaseObjectB.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "BaseObjectB.h"

@implementation BaseObjectB

- (void)fetchData
{
    // override to subclass
}

@end
