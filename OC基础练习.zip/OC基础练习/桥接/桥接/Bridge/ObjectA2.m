//
//  ObjectA2.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "ObjectA2.h"

@implementation ObjectA2

- (void)handle
{
    [super handle];
}


@end
