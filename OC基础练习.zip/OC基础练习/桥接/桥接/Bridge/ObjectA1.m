//
//  ObjectA1.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "ObjectA1.h"

@implementation ObjectA1

- (void)handle
{
    [super handle];
}

@end
