//
//  BaseObjectA.m
//  桥接
//
//  Created by 谢飞 on 2025/8/7.
//

#import "BaseObjectA.h"

@implementation BaseObjectA

/*
  A1 --> B1 B2 B3
  A2 --> B1 B2 B3
  A3 --> B1 B2 B3
 
*/

- (void)handle
{
    [self.objB fetchData];
}

@end
