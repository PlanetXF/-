//
//  ViewController.h
//  命令模式
//
//  Created by 谢飞 on 2025/8/8.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

