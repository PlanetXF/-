//
//  Command.h
//  命令模式
//
//  Created by 谢飞 on 2025/8/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class Command;
typedef void(^CommandCompletionCallBack)(Command* cmd); // block 的入参是一个命令类型的对象

@interface Command : NSObject

@property(nonatomic, copy) CommandCompletionCallBack completion;

- (void)execute;
- (void)cancel;

- (void)done;


@end

NS_ASSUME_NONNULL_END
