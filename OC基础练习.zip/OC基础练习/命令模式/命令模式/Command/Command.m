//
//  Command.m
//  命令模式
//
//  Created by 谢飞 on 2025/8/8.
//

#import "Command.h"
#import "CommandManager.h"

@implementation Command

- (void)execute
{
    // override to subclass
    [self done];
}

- (void)cancel
{
    self.completion = nil;
}

- (void)done
{
    // 异步回到主队列
    dispatch_async(dispatch_get_main_queue(), ^{
        if (_completion) {
            _completion(self);
        }
        // 释放
        self.completion = nil;
        
        [[CommandManager sharedInstance].arrayCommands removeObject:self];
        
    });
}

@end
