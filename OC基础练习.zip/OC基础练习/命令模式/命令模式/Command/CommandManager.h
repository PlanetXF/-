//
//  CommandManager.h
//  命令模式
//
//  Created by 谢飞 on 2025/8/8.
//

#import "Command.h"
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CommandManager : NSObject

// 命令管理容器
@property (nonatomic, strong) NSMutableArray <Command *> *arrayCommands;

// 命令管理者以单例的方式呈现
+ (instancetype)sharedInstance;

// 执行命令
+ (void)executeCommand:(Command *)cmd completion:(CommandCompletionCallBack)completion;

// 取消命令
+ (void)cancelCommand:(Command *)cmd;


@end

NS_ASSUME_NONNULL_END
