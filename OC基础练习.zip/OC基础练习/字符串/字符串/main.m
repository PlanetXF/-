//
//  main.m
//  字符串
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSString *str = @"Hello OC";
        NSLog(@"%lu", (unsigned long)str.length);

        NSString *newStr = [NSString stringWithFormat:@"%@-%d", str, 10];
        NSLog(@"%@", newStr);
        // 全部转大写
        NSLog(@"%@", [str uppercaseString]);
        // 全部转小写
        
        
        NSLog(@"%@", [str lowercaseString]);
        // 取字串：从什么下标开始(包含开始元素)
        NSLog(@"%@", [str substringFromIndex:2]);
        // 取字串：到什么下标结束(不包含结束元素)
        NSLog(@"%@", [str substringToIndex:2]);
        
        
        // 从某个下标开始取到某个下标结束(闭区间)
        NSRange range = NSMakeRange(2, 4);
        NSLog(@"%@", [str substringWithRange:range]);
        
        // 替换
        NSString *subStr = [str stringByReplacingOccurrencesOfString:[str substringWithRange:NSMakeRange(2, 5)] withString:@"xiefei"];
        NSLog(@"替换结果=%@", subStr);
        
        
        // 前缀
        NSLog(@"%@", [str hasPrefix: @"H"] ? @"true" : @"false");
        NSLog(@"%@", [str hasSuffix: @"H"] ? @"true" : @"false");
        // 截取字符串
        NSString *rangeStr = [str substringWithRange:NSMakeRange(0, 5)];
        NSLog(@"%@", rangeStr);
        
        
        NSMutableString *mutStr = [NSMutableString stringWithString:@""]; // 不能使用字面量初始化
        
        [mutStr setString:@"xf"];
        
        [mutStr appendString:@" good man"];
        
        [mutStr insertString:@"hello " atIndex:0];
        
        [mutStr replaceCharactersInRange:NSMakeRange(0, 5) withString:@"nihao"];
        
        NSLog(@"可变 %@", mutStr);
        
        
        NSString *appendStr = [mutStr stringByAppendingString:@"hahaha"];
        NSLog(@"拼接 %@", appendStr);
    }
     return 0;
}
