import UIKit

var arr = [1, 3, 4, 5, 7, 5];

func getMiddle(nums: [Int]) -> Int {
    var arr = nums;
    let sortedArr = quickSort(&arr, 0, arr.count - 1)
    
    
    
    return 1;
}

func quickSort(_ arr: inout [Int], _ low: Int, _ high: Int ) -> [Int] {
    if low < high {
        let pivotIndex = partition(&arr, low, high)
        quickSort(&arr, low, pivotIndex - 1)
        quickSort(&arr, pivotIndex + 1, high)
    }
    return arr
}

func partition(_ arr: inout [Int], _ low: Int, _ high: Int) -> Int {
    let randomIndex = Int.random(in: low...high)
    arr.swapAt(randomIndex, high)
    
    var pivot = arr[high]
    var i = low
    
    for j in low..<high {
        if arr[j] < pivot {
            arr.swapAt(j, i)
            i += 1
        }
    }
    
    arr.swapAt(i, high)
    return i
}

var str: String = "1231 1231 322"
str.trimmingCharacters(in: .whitespaces).split(separator: "")


