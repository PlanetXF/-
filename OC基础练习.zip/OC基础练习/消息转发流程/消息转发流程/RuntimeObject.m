//
//  RuntimeObject.m
//  消息转发流程
//
//  Created by 谢飞 on 2025/7/26.
//

#import "RuntimeObject.h"
#import "objc/runtime.h"

@implementation RuntimeObject


//+ (void)load
//{
//    // 获取test方法
//    Method test = class_getInstanceMethod(self, @selector(test));
//    // 获取otherTest方法
//    Method otherTest = class_getInstanceMethod(self, @selector(otherTest));
//    method_exchangeImplementations(test, otherTest);
//    NSLog(@"load");
//}
//
//- (void)test
//{
//    NSLog(@"test");
//}
//
//- (void)otherTest
//{
//    // 实际上调用的test方法
//    [self otherTest];
//    NSLog(@"otherTest");
//}

void testImp (void)
{
    NSLog(@"test invoke");
}

+ (BOOL)resolveInstanceMethod:(SEL)sel
{
    if (sel == @selector(test)) {
        NSLog(@"resolveInstanceMethod:");
        
        // 动态添加test方法的实现
//        class_addMethod(self, @selector(test), testImp, "v@:");
//        return YES;
        
        return NO;
    } else {
        return [super resolveInstanceMethod:sel];
    }
}

+ (id)forwardingTargetForSelector:(SEL)aSelector
{
    NSLog(@"forwardingTargetForSelector:");
    return nil;
}

+ (NSMethodSignature *)instanceMethodSignatureForSelector:(SEL)aSelector
{
    if (aSelector == @selector(test)) {
        NSLog(@"instanceMethodSignatureForSelector:");
        
        // v 代表返回值void类型 @代表第一个参事类型是id 即self
        // ：代表第二个参数是SEL类型的 即 @selector(test)
        return [NSMethodSignature signatureWithObjCTypes:"v@:"];
    } else {
        return [super methodSignatureForSelector:aSelector];
    }
}

+ (void)forwardInvocation:(NSInvocation *)anInvocation
{
    NSLog(@"forwardInvocation:");
}

@end
