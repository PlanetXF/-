//
//  SceneDelegate.h
//  消息转发流程
//
//  Created by 谢飞 on 2025/7/26.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

