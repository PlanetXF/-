//
//  RuntimeObject.h
//  消息转发流程
//
//  Created by 谢飞 on 2025/7/26.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface RuntimeObject : NSObject


- (void)test;
@end

NS_ASSUME_NONNULL_END
