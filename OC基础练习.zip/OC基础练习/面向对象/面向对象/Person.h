//
//  Person.h
//  面向对象
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

@property(nonatomic, copy) NSString *name;
@property(nonatomic, copy) NSString *sex;
@property(nonatomic, assign) NSInteger age;
@property(nonatomic, strong) NSArray *children;

+ (void)say;
- (void)eat:(NSString *)food;
- (NSString *)sleep:(NSString *)time;

- (instancetype)initWithName:(NSString *)name Sex:(NSString *)sex Age:(NSInteger)age Children:(NSArray *)children;

@end

NS_ASSUME_NONNULL_END
