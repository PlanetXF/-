//
//  Student.h
//  面向对象
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Student : Person

@property(copy, nonatomic) NSString *stuNo; // @property 同时实现set get方法 和 _stuNo

@end

NS_ASSUME_NONNULL_END
