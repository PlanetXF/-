//
//  main.m
//  面向对象
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Student.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Person *p = [[Person alloc] init];
        p.name = @"xf";
        p.age = 18;
        p.sex = @"male";
        p.children = @[@"1mao", @"2mao", @"3mao"];
        
        [Person say];
        [p eat:@"苹果"];
        NSLog(@"%@", [p sleep:@"7:00"]);
        
        Student *stu = [[Student alloc] init];
        stu.stuNo = @"12345678"; 
        [stu sleep:@"6:00"];
        NSLog(@"%@", stu.stuNo);
        
        
        // 多态：父类型的指针指向子类型
        Person *ps = [[Student alloc] init];
        [ps sleep:@"5:00"];
        
        Person *p2 = [[Person alloc] initWithName:@"xf" Sex:@"male" Age:@"29" Children:@[@"123", @"234"]];
        NSLog(@"%@", p2.name);
        NSLog(@"%ld", p2.age);
        NSLog(@"%@", p2.sex);
        NSLog(@"%@", p2.children);
    }
    return 0;
}
