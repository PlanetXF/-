//
//  Person.m
//  面向对象
//
//  Created by 谢飞 on 2025/6/28.
//

#import "Person.h"

@implementation Person

- (instancetype)initWithName:(NSString *)name Sex:(NSString *)sex Age:(NSInteger)age Children:(NSArray *)children
{
    if (self = [super init]) {
        self.name = name;
        self.sex = sex;
        self.age = age;
        self.children = children;
    }
    return self;
}

+ (void)say
{
    NSLog(@"人说话");
}

- (void)eat:(NSString *)food
{
    NSLog(@"人喜欢吃%@", food);
}

-(NSString *)sleep:(NSString *)time
{
    NSLog(@"人%@点睡觉", time);
    return @"睡得好";
}

@end
