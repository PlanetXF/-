//
//  Student.m
//  面向对象
//
//  Created by 谢飞 on 2025/6/28.
//

#import "Student.h"

@interface Student ()


@end

@implementation Student

- (NSString *)sleep:(NSString *)time
{
    NSLog(@"学生%@睡觉", time);
    return @"学生睡觉好啊";
}

// get方法
- (NSString *)stuNo
{
    return _stuNo;
}

//- (void)setStuNo:(NSString *)stuNo
//{
//    _stuNo = stuNo;
//}

- (NSString *)description
{
    return [NSString stringWithFormat:@"当前学生的信息为%@", self.stuNo];
}
@end
