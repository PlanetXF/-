import UIKit

var a: Int?
var b: Int = 0

a = 3

if let a = a {
//    print(a)
}

var obj: Dictionary = ["":""]

class Person {
    let name: String
    let age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}

class Teacher: Person {
    let subject: String
    
    init(subject: String, name: String, age: Int) {
        self.subject = subject
        super.init(name: name, age: age)
    }
}

let xiefei = Person(name: "xiefei", age: 20)
let xf = Teacher(subject: "chinese", name: "xf", age: 23)

//print(type(of: a))
//print(type(of: obj))
//print(type(of: xiefei))
//
//print(type(of: xiefei) == Person.self)// true
//print(type(of: xf) == Person.self)// false

//print(xf is Person)

func Hello(a: Int) -> Int {
//    print("Hello")
    return a + 1
}

 

var result = Hello(a: 5)
print(result) // 6

let bibao = { () in
//    "nihao"
    print("")
}

print(bibao())


