import UIKit

func sum(a: Int, b: Int) -> Int {
    return a + b
}

//print(sum(a: 1, b: 2))

let sumBlock = { (a: Int, b: Int) -> Int in
    a + b
}

//print(sumBlock(1, 2))


func hi(name: String) {
    print("hello")
}

let hiBlock = { (name: String) in
    print("hello \(name)")
}

//hiBlock("xf")

func sayHi(action: () -> Void) {
    action()
    print("xf")
}

//sayHi(action: {
//    print("hello")
//})
//
//// 尾随闭包
//sayHi {
//    print("hello")
//}


// 函数的参数是另一个函数

//func travel(action: (String) -> Void) {
//    print("我现在出发")
//    action("郑州")
//    print("我已经到了")
//}
//
//travel { (place: String) in
//    print("我坐火车去\(place)")
//}

//print(compeletStr)

// 返回值是一个函数

//func travel() -> (String)->Void {
//    return { (place:String) in
//        print("我想去\(place)")
//    }
//}
//let resBlock = travel()
//resBlock("郑州")

func read(book: String) -> () -> (){
    print("我正在读\(book)")
    var counter = 0
    return {
        counter += 1
        print("第\(counter)次读\(book)")
    }
}

let readBlock = read(book: "三国")
readBlock()
readBlock()
