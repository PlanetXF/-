//
//  main.m
//  字典
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSDictionary *dict = @{@"name" : @"xiefei", @"age" : @"18" , @"sex" : @"male"};
        
    
        [dict allKeys];
        [dict allValues];
        
        for (NSString *key in [dict allKeys]) {
//            NSLog(@"%@ -- %@", key, dict[key]);
            NSLog(@"%@ -- %@", key, [dict valueForKey:key]);
        }
        
        for (NSString *value in [dict allValues]) {
            NSLog(@"%@", value);
        }
        
        NSMutableDictionary *mutDict = [NSMutableDictionary dictionaryWithDictionary:dict];
        NSLog(@"可变字典 - %@", mutDict);
        
        // 增加键值对
        [mutDict setObject:@"football" forKey:@"hobby"];
        // 修改值
        mutDict[@"hobby"] = @"baskteball";
        // 移除键值对
        [mutDict removeObjectForKey:@"hobby"];
        
        
        NSLog(@"可变字典 - %@", mutDict);
        
    }
    return 0;
}
