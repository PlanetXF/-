//
//  AppDelegate.h
//  CGD其他两个函数
//
//  Created by 谢飞 on 2025/8/31.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

