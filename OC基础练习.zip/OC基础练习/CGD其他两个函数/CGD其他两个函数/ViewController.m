//
//  ViewController.m
//  CGD其他两个函数
//
//  Created by 谢飞 on 2025/8/31.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    dispatch_queue_t concurrentQueue = dispatch_queue_create("谢飞", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_queue_t serialQueue = dispatch_queue_create("谢飞", DISPATCH_QUEUE_SERIAL);
    
    // 多次并发迭代执行block
    dispatch_apply(3, concurrentQueue, ^(size_t iteration) {
        NSLog(@"apply %zu", iteration);
    });
    
    // 多次串行迭代执行block
    dispatch_apply(3, serialQueue, ^(size_t iteration) {
        NSLog(@"apply %zu", iteration);
    });
    
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSLog(@"我只执行一次");
    });
    
}


@end
