//
//  buyTicket.h
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol buyTicket <NSObject>

@required // 必须实现
- (void)buy;
@optional // 可选
- (void)sell;

@end

NS_ASSUME_NONNULL_END
