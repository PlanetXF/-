//
//  Boss.h
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "buyTicket.h"

NS_ASSUME_NONNULL_BEGIN

@interface Boss : NSObject

@property(nonatomic, weak) id<buyTicket> ticketDelegate;

- (void)buyTicket;

@end

NS_ASSUME_NONNULL_END
