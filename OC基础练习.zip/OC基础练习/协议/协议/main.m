//
//  main.m
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "Boss.h"
#import "AClass.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // 代理对象： 具体做事class
        // 协议：沟通桥梁
        // 被代理对象： 真正想做事的class
        
        
        Boss *b = [[Boss alloc] init];
        AClass *a = [[AClass alloc] init];
        b.ticketDelegate = a;
        [b buyTicket];
        
    }
    return 0;
}
