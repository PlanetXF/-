//
//  Boss.m
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import "Boss.h"

@implementation Boss

- (void)buyTicket
{
    if ([self.ticketDelegate respondsToSelector:@selector(buy)]) {
        [self.ticketDelegate buy];
    }
}

@end
