//
//  AClass.m
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import "AClass.h"

@implementation AClass

- (void)buy
{
    NSLog(@"A买票");
}

@end
