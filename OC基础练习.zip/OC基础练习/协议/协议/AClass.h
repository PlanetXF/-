//
//  AClass.h
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>
#import "buyTicket.h"

NS_ASSUME_NONNULL_BEGIN

@interface AClass : NSObject <buyTicket>

@end

NS_ASSUME_NONNULL_END
