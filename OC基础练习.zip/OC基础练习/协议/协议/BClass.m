//
//  BClass.m
//  协议
//
//  Created by 谢飞 on 2025/6/28.
//

#import "BClass.h"

@implementation BClass

- (void)buy
{
    NSLog(@"B买票");
}


@end
