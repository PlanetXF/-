import UIKit

// 集合：无序不重复
var s: Set<Int> = [1, 2, 3, 4, 5]
var s1 = Set([1, 2, 3, 4, 5])
print(s1)


var a = Set(["苹果","香蕉","桔子","柚子","橙子"])
var b = Set(["桃子","香蕉","桔子","甜瓜","甜瓜"])

print(a.count)
print(a.isEmpty)

//var (success, c) = a.insert("apple")
//print(success, c)
//print(a)

//a.update(with: "pear") // 强行插入
//print(a)

//a.remove("苹果")
//a.removeAll()
//print(a)


// 集合并集，去重合并
print(a.union(b))
// 集合的差集
print(a.subtracting(b))
print(b.subtracting(a))
// 集合的交集
print(a.intersection(b))
// 集合的补集
print(a.symmetricDifference(b))

// 子集
print(a.isSubset(of: b))
// 超集
print(a.isSuperset(of: b))
// 随机数
print(a.randomElement() ?? "")








