//
//  Mooc.m
//  单例
//
//  Created by 谢飞 on 2025/8/8.
//

#import "Mooc.h"

@implementation Mooc

+ (instancetype)sharedInstance
{
    // 静态局部变量
    static Mooc *instance = nil;
    
    // 通过dispatch_once的方式 确保instance在多线程环境下只被创建一次
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 创建实例
        instance = [[super allocWithZone:NULL] init];
    });
    return instance;
}

// 重写方法【必不可少】
+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    return [self sharedInstance];
}

// 重写方法【必不可少】
+ (id)copyWithZone:(struct _NSZone *)zone OBJC_ARC_UNAVAILABLE;
{
    return self;
}



@end
