//
//  Mooc.h
//  单例
//
//  Created by 谢飞 on 2025/8/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Mooc : NSObject

@end

NS_ASSUME_NONNULL_END
