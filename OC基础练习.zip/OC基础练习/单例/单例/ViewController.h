//
//  ViewController.h
//  单例
//
//  Created by 谢飞 on 2025/8/8.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

