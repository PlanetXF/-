//
//  ViewController.m
//  CGD任务与队列
//
//  Created by 谢飞 on 2025/8/31.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self gcd01];
}

- (void)gcd01
{
    // 获取主队列
    dispatch_queue_t main = dispatch_get_main_queue();
    // 获取全局队列
    dispatch_queue_t globalQueue = dispatch_get_global_queue(0, 0);
    // 创建一个并发队列
    dispatch_queue_t selfConcurrent = dispatch_queue_create(@"并发队列", DISPATCH_QUEUE_CONCURRENT);
    // 创建一个串行队列
    dispatch_queue_t selfSerial = dispatch_queue_create(@"串行队列", DISPATCH_QUEUE_SERIAL);
    

    // 同步并发，同步串行会导致死锁
//    dispatch_sync(globalQueue, ^{
//        for (int i=0; i<5; i++) {
//            NSLog(@"%d -- %@", i, [NSThread currentThread]);
//        }
//    });
    
    
    // 异步串行，回到主队列，执行线程是主线程
//    dispatch_async(main, ^{
//        for (int i=0; i<5; i++) {
//            NSLog(@"%d -- %@", i, [NSThread currentThread]);
//        }
//    });
    
    // 异步串行，创建新线程
//    dispatch_async(selfSerial, ^{
//        for (int i=0; i<5; i++) {
//            NSLog(@"%d -- %@", i, [NSThread currentThread]);
//        }
//    });
    
    //异步并发
//    dispatch_async(globalQueue, ^{
//        for (int i=0; i<5; i++) {
//            NSLog(@"%d -- %@", i, [NSThread currentThread]);
//        }
//    });
    
}




@end
