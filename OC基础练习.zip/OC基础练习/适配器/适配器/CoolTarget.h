//
//  CoolTarget.h
//  适配器
//
//  Created by 谢飞 on 2025/8/8.
//

#import "Target.h"
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

// 适配对象
@interface CoolTarget : NSObject
// 被适配对象
@property(nonatomic, strong) Target *target;

- (void)request;

@end

NS_ASSUME_NONNULL_END
