//
//  CoolTarget.m
//  适配器
//
//  Created by 谢飞 on 2025/8/8.
//

#import "CoolTarget.h"

@implementation CoolTarget

- (void)request
{
    // 额外处理
    
    [self.target operation];
    
    // 额外处理
}


@end
