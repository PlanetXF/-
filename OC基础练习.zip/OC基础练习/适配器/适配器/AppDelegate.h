//
//  AppDelegate.h
//  适配器
//
//  Created by 谢飞 on 2025/8/8.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

