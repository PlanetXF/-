//
//  Target.m
//  适配器
//
//  Created by 谢飞 on 2025/8/8.
//

#import "Target.h"

@implementation Target

- (void)operation
{
    // 原有的具体的逻辑
}

@end
