//
//  ViewController.m
//  适配器
//
//  Created by 谢飞 on 2025/8/8.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
