//
//  Target.h
//  适配器
//
//  Created by 谢飞 on 2025/8/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target : NSObject

- (void)operation;

@end

NS_ASSUME_NONNULL_END
