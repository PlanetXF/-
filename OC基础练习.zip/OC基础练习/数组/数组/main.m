//
//  main.m
//  数组
//
//  Created by 谢飞 on 2025/6/28.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSArray *array = [[NSArray alloc] init];
        // 数组中必须放对象类型，不能放基本类型，可以放多种类型
        // 基本数据类型前面用@修饰后，就会变成被封装成对象 例如 NSNumber
        array = @[@1, @2.0, @"123"];
        
        NSLog(@"%@", array[0]);
        
//        for (id item in array) {
//            NSLog(@"%@", item);
//        }
        
        for (int i = 0; i < array.count; i++) {
            NSLog(@"%@--%d", array[i], i);
        }
        
        NSInteger index = [array indexOfObject:@"123"];
        NSLog(@"%@的下标是%ld", @"123", (long)index);
        
        // 可变数组
        NSMutableArray *muArray = [NSMutableArray arrayWithArray:array]; // 完整的复制
        // 末尾添加元素
        [muArray addObject:@"1234"];
        // 移除元素
        [muArray removeObject:@1];
        // 指定位置插入元素
        [muArray insertObject:@"789" atIndex:3];
        // 替换某个下标的元素
        [muArray replaceObjectAtIndex:1 withObject:@"777"];
        // 删除某个位置的元素
        [muArray removeObjectAtIndex:3];
        NSLog(@"可变数组 - %@", muArray);
        
        
        NSArray *numberArray = @[@123, @456, @789];
        NSInteger index1 = [numberArray indexOfObject: @123];
        NSLog(@"下标 - %ld", (long)index1);
        
        // 是否包含
        BOOL isContains = [numberArray containsObject: @123];
        NSLog(@"%@", isContains ? @"true" : @"false");
        
        NSNumber *first = [numberArray firstObject];
        NSLog(@"第一个 - %ld", (long)first.integerValue);
        
        
        
        
    }
    return 0;
}
